from setuptools import setup, find_packages


setup(
    name='echoapp',
    packages=find_packages(),
    install_requires=[
        'flask',
    ],
)
