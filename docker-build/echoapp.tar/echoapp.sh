#!/bin/sh

exec echoapp
