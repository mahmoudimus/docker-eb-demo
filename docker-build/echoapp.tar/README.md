docker-eb-demo
==============

An example demonstrates how to run a Docker app with AWS Elastic Beanstalk

## Setup

- install Vagrant (minimum vagrant version 1.7.1)
- vagrant up


## References

- Read the article [Running Docker with AWS Elastic Beanstalk](http://victorlin.me/posts/2014/11/26/running-docker-with-aws-elastic-beanstalk)
